// Licensed to the Software Freedom Conservancy (SFC) under one
// or more contributor license agreements.  See the NOTICE file
// distributed with this work for additional information
// regarding copyright ownership.  The SFC licenses this file
// to you under the Apache License, Version 2.0 (the
// "License"); you may not use this file except in compliance
// with the License.  You may obtain a copy of the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing,
// software distributed under the License is distributed on an
// "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
// KIND, either express or implied.  See the License for the
// specific language governing permissions and limitations
// under the License.

package learnings.selenium4official.client.test.org.openqa.selenium.environment.webserver;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.http.HttpClient;
import org.openqa.selenium.remote.http.HttpMethod;
import org.openqa.selenium.remote.http.HttpRequest;
import org.openqa.selenium.remote.http.HttpResponse;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.testing.drivers.WebDriverBuilder;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.stream.StreamSupport;

public abstract class AppServerTestBase {
  private static final String APPCACHE_MIME_TYPE = "text/cache-manifest";
  private AppServer server;
  private static WebDriver driver;

  @BeforeClass
  public static void startDriver() {
    driver = new WebDriverBuilder().get();
  }

  @Before
  public void startServer() {
    server = createAppServer();
    server.start();
  }

  protected abstract AppServer createAppServer();

  @After
  public void stopServer() {
    server.stop();
  }

  @AfterClass
  public static void quitDriver() {
    driver.quit();
  }

  @Test
  public void hostsStaticPages() {
    driver.get(server.whereIs("simpleTest.html"));
    assertEquals("Hello WebDriver", driver.getTitle());
  }

  @Test
  public void servesNumberedPages() {
    driver.get(server.whereIs("page/1"));
    assertEquals("Page1", driver.getTitle());

    driver.get(server.whereIs("page/2"));
    assertEquals("Page2", driver.getTitle());
  }

  @Test
  public void numberedPagesExcludeQuerystring() {
    driver.get(server.whereIs("page/1?foo=bar"));
    assertEquals("1", driver.findElement(By.id("pageNumber")).getText());
  }

  @Test
  public void redirects() {
    driver.get(server.whereIs("redirect"));
    assertEquals("We Arrive Here", driver.getTitle());
    assertTrue(driver.getCurrentUrl().contains("resultPage"));
  }

  @Test
  public void sleeps() {
    long before = System.currentTimeMillis();
    driver.get(server.whereIs("sleep?time=1"));

    long duration = System.currentTimeMillis() - before;
    assertTrue(duration >= 1000);
    assertTrue(duration < 1500);
    assertEquals("Slept for 1s", driver.findElement(By.tagName("body")).getText());
  }

  @Test
  public void dealsWithUtf16() {
    driver.get(server.whereIs("encoding"));
    String pageText = driver.findElement(By.tagName("body")).getText();
    assertTrue(pageText.contains("\u05E9\u05DC\u05D5\u05DD"));
  }

  @Test
  public void manifestHasCorrectMimeType() throws IOException {
    assertUrlHasContentType(server.whereIs("html5/test.appcache"), APPCACHE_MIME_TYPE);
  }

  @Test
  public void manifestHasCorrectMimeTypeUnderJavascript() throws IOException {
    String appcacheUrl =
        server.whereIs("/javascript/atoms/test/html5/testdata/with_fallback.appcache");
    assertUrlHasContentType(appcacheUrl, APPCACHE_MIME_TYPE);
  }

  @Test
  public void uploadsFile() throws Throwable {
    String FILE_CONTENTS = "Uploaded file";
    File testFile = File.createTempFile("webdriver", "tmp");
    testFile.deleteOnExit();
    Files.write(testFile.toPath(), FILE_CONTENTS.getBytes());

    driver.get(server.whereIs("upload.html"));
    driver.findElement(By.id("upload")).sendKeys(testFile.getAbsolutePath());
    driver.findElement(By.id("go")).submit();

    // Nasty. Sorry.
    Thread.sleep(50);

    driver.switchTo().frame("upload_target");
    new WebDriverWait(driver, 10).until(
        d -> d.findElement(By.xpath("//body")).getText().equals(FILE_CONTENTS));
  }

  private void assertUrlHasContentType(String url, String appcacheMimeType) throws IOException {
    HttpClient.Factory factory = HttpClient.Factory.createDefault();
    HttpClient client = factory.createClient(new URL(url));
    HttpResponse response = client.execute(new HttpRequest(HttpMethod.GET, url));

    assertTrue(StreamSupport.stream(response.getHeaders("Content-Type").spliterator(), false)
        .anyMatch(header -> header.contains(appcacheMimeType)));
  }
}
